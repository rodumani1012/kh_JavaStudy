$(function () {

    $("body").prop("class", "sidebar-visible")

    // Sidebar .prj_bar
    $('.toggle').click(function () {
        var emp = "";
        $("body").prop("class", function (i, val) {
            if (val === "") {
                emp = "sidebar-visible"
            }
            $("body").prop("class", emp);
        })
    })

    // board_title_update
    $('.board_title').on('dblclick', function () {
        var before_title = $(this).find('strong').text()
        var board_num = $(this).prop('id')
        $('strong').css('display', 'inline')
        $('.emp_title').remove()
        $(this)
            .append(
                `<input type="text" value="${before_title}" class="emp_title" onkeypress="board_update($(this).val(), ${board_num})">`)
        $(this).find('strong').css('display', 'none')


    })

    // board_title_update 초기화
    $(document).on('click', function (e) {
        if (!$(e.target).is('.emp_title')) {
            $('strong').css('display', 'inline')
            $('.emp_title').remove()
        }
    })

    $('.chat_room').on('click', function () {
        var url = "project/meeting/chat_room.jsp";
        var title = "myframe";
        var prop = "top=200px,left=600px,width=450,height=750px";
        //open("팝업으로 실행할 파일 주소","팝업이 열릴 창 이름"[,"옵션"])
        window.open(url, title, prop);
    })

})

// board_update
function board_update(to_title, board_num) {
    if (event.keyCode == 13) {
        $.ajax({
            url: `project.do?command=board_update&board_num=${board_num}&to_title=${to_title}`,
            method: 'post',
            success: function () {
                $('.board_title').find('input').after(
                    `<strong>${to_title} </strong>`)
                $('.board_title').find('input').remove()
            },
            error: function () {
                alert('error')
            }
        })
    }
}

// 대쉬보드
// board_new
function board_new(num) {
    var title = $('#board_title').val().trim()
    var prj_num = "prj_num=" + num;

    if (title == null || title == "") {
        alert("보드의 이름을 입력해주세요")
    } else {
        $.ajax({
            url: "project.do?command=board_new&title=" + title + "&"
                + prj_num,
            success: function () {
                location.href = `project.do?command=board_manager&prj_num=${num}`
            },
            error: function () {
                alert("실패")
            }
        })
    }
}

// board_delete
function board_delete(board_num, prj_num) {
    if (confirm('보드에 속한 이슈들이 모두 삭제 됩니다.')) {
        $.ajax({
            url: `project.do?command=board_delete&board_num=${board_num}`,
            method: 'post',
            success: function () {
                location.href = `project.do?command=board_manager&prj_num=${prj_num}`
            },
            error: function () {
                alert('error')
            }
        })
    }

}