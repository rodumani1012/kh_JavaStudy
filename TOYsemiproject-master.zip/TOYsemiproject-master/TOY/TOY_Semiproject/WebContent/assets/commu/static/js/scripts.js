//import { SSL_OP_NETSCAPE_DEMO_CIPHER_CHANGE_BUG } from "constants";

(function () {
  var App;
  App = {};
  /*
	 * Init
	 */



  App.init = function () {
    App.canvas = document.createElement('canvas');
    App.canvas.height = window.innerHeight / 2
    App.canvas.width = window.innerWidth
    document.getElementsByTagName('article')[0].appendChild(App.canvas);
    App.ctx = App.canvas.getContext("2d");
    App.ctx.fillStyle = "solid";
    App.ctx.strokeStyle = "#ff0000";
    App.ctx.lineWidth = 5;
    App.ctx.lineCap = "round";
    App.ctx.globalCompositeOperation = "source-over";
    App.socket = io.connect('http://192.168.10.139:8000');


    App.socket.on('draw', function (data) {
      return App.draw(data.x, data.y, data.type, data.style, data.cap, data.width, data.eraser);
    });

    App.socket.on('color', function (data) {
      App.ctx.strokeStyle = data;
    })



    App.draw = function (x, y, type, style, cap, width, eraser) {
      if (type === "dragstart") {
        App.ctx.strokeStyle = style;
        App.ctx.lineWidth = width;
        App.ctx.lineCap = cap;
        App.ctx.globalCompositeOperation = eraser
        App.ctx.beginPath();
        return App.ctx.moveTo(x, y);
      } else if (type === "drag") {
        App.ctx.lineTo(x, y);
        return App.ctx.stroke();
      } else {
        changer()
        return App.ctx.closePath();
      }
    };
  };

  $('#line_change').click(function () {
    changer()
  })

  function changer() {
    var strokeStyle = $('#strokestyle').val()
    var lineCap = $('#linecap').val()
    var lineWidth = $('#linewidth').val()

    App.ctx.globalCompositeOperation = "source-over";
    App.ctx.strokeStyle = strokeStyle
    App.ctx.lineCap = lineCap
    App.ctx.lineWidth = lineWidth
  }

  $('#eraser').click(function () {
    var strokeStyle = $('#strokestyle').val()
    var lineCap = $('#linecap').val()
    var lineWidth = $('#linewidth').val()

    App.ctx.globalCompositeOperation = "destination-out";
    App.ctx.strokeStyle = strokeStyle
    App.ctx.lineCap = lineCap
    App.ctx.lineWidth = lineWidth
  })

  /*
	 * Draw Events
	 */
  $('canvas').live('drag dragstart dragend', function (e) {
    var offset, type, x, y;
    var style = App.ctx.strokeStyle;
    var cap = App.ctx.lineCap;
    var width = App.ctx.lineWidth;
    var eraser = App.ctx.globalCompositeOperation
    type = e.handleObj.type;
    offset = $(this).offset();
    // e.offsetX = e.layerX - offset.left;
    // e.offsetY = e.layerY - offset.top;
    x = e.offsetX;
    y = e.offsetY;
    App.draw(x, y, type, style, cap, width, eraser);
    App.socket.emit('drawClick', {
      x: x,
      y: y,
      type: type,
      style: style,
      cap: cap,
      width: width,
      eraser: eraser
    });
  });

  $(function () {
    return App.init();
  });
}).call(this);


